package hangman;
import java.awt.Button;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.*;

import sun.applet.Main;
public class Hangman extends JFrame{
	//
	private static Timer timer = null;
	private static Timer timer1 = null;
	private static Timer timer2 = null, timer3 = null, timer4 = null, timer5 = null, timer6 = null;
	public static int screenX = 750, screenY = 1000, score = 0, PlayerMadeMistake = 0;
	public static int Correct = 0, Health = 4, Charecter = 0;
	public static int WinCount = 0, loseCount=0;
	public static int Wins, Loses, Gamemode = 0, GameMode = 1;
	public static Random rand = new Random(), event = new Random();
	public static int[] stats = new int[3];
	public static String[][] words = new String[4][19], pictures = new String[4][4];
	public static JFrame frame = new JFrame("Hangman");
	public static JFrame frame1 = new JFrame("Hangman");
	public static JLabel scoreboard = new JLabel("Score: " + score);
	private static Clip audioClip;
	public static void main(String args[]){
	//read from file and store variables
	int Counter = 0;
	FileReader filereader = null;
	try {
		filereader = new FileReader("stats.txt");
		BufferedReader reader = new BufferedReader(filereader);
		
		String str;
		while((str = reader.readLine())!= null){
			stats[Counter] = Integer.parseInt(str);
			Counter++;
		}
		Wins = stats[1];
		Loses = stats[2];
		System.out.println(stats[0]+"\n"+stats[1]+"\n"+stats[2]);
	} catch (FileNotFoundException e1) {
		
	} catch (IOException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	
	
	//frame stuff
		frame = new JFrame();
		frame.setVisible(true);
		frame.setBackground(Color.WHITE);
		frame.setBounds(100, 100, 770, 450);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		frame.getContentPane().setLayout(null);
		JButton startButton = new JButton("Story");
		startButton.setOpaque(false);
		startButton.setContentAreaFilled(false);
		startButton.setBorderPainted(false);
		startButton.setForeground(Color.RED);
		startButton.setBounds(640, 200, 100, 23);
		
		JButton themeButton = new JButton("Fun Mode");
		themeButton.setOpaque(false);
		themeButton.setContentAreaFilled(false);
		themeButton.setBorderPainted(false);
		themeButton.setForeground(Color.RED);
		themeButton.setBounds(630, 250, 110, 23);
		
		JButton Button = new JButton("Multi!!!!");
		Button.setOpaque(false);
		Button.setContentAreaFilled(false);
		Button.setBorderPainted(false);
		Button.setForeground(Color.YELLOW);
		Button.setBounds(630, 150, 110, 23);
		
		
		frame.getContentPane().add(startButton);
		if (stats[0] == 1){
			frame.getContentPane().add(themeButton);
		}
		if (stats[1] >= 10){
			frame.getContentPane().add(Button);
		}
		timer = new Timer(10140, new ActionListener(){ // Timer 4 seconds
            public void actionPerformed(ActionEvent e) {
            	timer.stop();
            	Intro();
            	
            }
        }); 
		startButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GameMode = 1;
				frame.getContentPane().removeAll();
				frame.getContentPane().repaint();
				JLabel Fade = new JLabel("");
				Fade.setBounds(0, 0, 770, 450);
				Fade.setIcon(new ImageIcon("fadetoblack.gif"));
				frame.getContentPane().add(Fade);
			   timer.start();
				 
			}
		});	
		themeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GameMode = 2;
				frame.getContentPane().removeAll();
				frame.getContentPane().repaint();
					CharPicChooser();
				
				
				 
			}
		});
		Button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GameMode = 3;
				frame.getContentPane().removeAll();
				frame.getContentPane().repaint();
				CharPicChooser();
				 
			}
		});
		JLabel MenuPic = new JLabel("");
		MenuPic.setBounds(0, 0, 764, 450);
		frame.getContentPane().add(MenuPic);
		MenuPic.setIcon(new ImageIcon("menuPicture.jpg"));	
	}
	public static void Intro(){
		
		frame.getContentPane().removeAll();
		frame.getContentPane().repaint();
		frame.getContentPane().setBackground(Color.BLACK);
		frame.setBackground(Color.WHITE);
		frame.setBounds(100, 100, 770, 450);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		frame.getContentPane().setLayout(null);
		JLabel CharGif = new JLabel("");
		CharGif.setForeground(new Color(255, 255, 240));
		CharGif.setIcon(new ImageIcon("D:\\workspace\\HangMan RST\\Talking.gif"));
		CharGif.setBounds(0, 11, 195, 242);
		frame.getContentPane().add(CharGif);
//
		JButton button = new JButton("Next...");
		button.setOpaque(false);
		button.setContentAreaFilled(false);
		button.setBorderPainted(false);
		button.setForeground(new Color(165, 42, 42));
		button.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 13));
		button.setBounds(623, 376, 115, 35);

		frame.getContentPane().add(button);
//
		JTextPane txt = new JTextPane();
		txt.setFont(new Font("Balthazar", Font.BOLD | Font.ITALIC, 31));
		txt.setText("Where am I? I must have bumped my head somewhere since I cannot remember a darn thing. I cannot remember where I came from, my name, or even who I am! This is so very strange... Wait, what is that sound?");
		txt.setForeground(new Color(165, 42, 42));
		txt.setBackground(Color.DARK_GRAY);
		txt.setBounds(0, 251, 764, 170);
		txt.setEditable(false); 
		frame.getContentPane().add(txt);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
//
				Intro2();
			}
		});	
	}
	public static Clip audioClip2;
	public static void Intro2(){
		//
		frame.getContentPane().removeAll();
		frame.getContentPane().repaint();
		frame.getContentPane().setBackground(Color.BLACK);
		frame.setBackground(Color.WHITE);
		frame.setBounds(100, 100, 770, 450);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		frame.getContentPane().setLayout(null);
//
		JLabel Scary = new JLabel("");
		Scary.setIcon(new ImageIcon("D:\\workspace\\HangMan RST\\scarygirl1.gif"));
		Scary.setBounds(213, 113, 382, 179);
		frame.getContentPane().add(Scary);
		timer.start();
		//
		JButton text = new JButton("What is that...");
		text.setOpaque(false);
		text.setContentAreaFilled(false);
		text.setBorderPainted(false);
		text.setForeground(new Color(165, 42, 42));
	//
		text.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 34));
		text.setBounds(260, 245, 293, 165);
		frame.getContentPane().add(text);
		File audioFile = new File("D:/workspace/HangMan RST/scream1.wav");
   	 
        try {
            AudioInputStream audioStream = AudioSystem.getAudioInputStream(audioFile);
 
            AudioFormat format = audioStream.getFormat();
 
            DataLine.Info info = new DataLine.Info(Clip.class, format);
 
            Clip audioClip1 = (Clip) AudioSystem.getLine(info);
            audioClip2 = audioClip1;
            audioClip2.open(audioStream);
             
            
            
             
        } catch (UnsupportedAudioFileException ex) {
            System.out.println("The specified audio file is not supported.");
            ex.printStackTrace();
        } catch (LineUnavailableException ex) {
            System.out.println("Audio line for playing back is unavailable.");
            ex.printStackTrace();
        } catch (IOException ex) {
            System.out.println("Error playing the audio file.");
            ex.printStackTrace();
        }

		timer2 = new Timer(1190, new ActionListener(){// Timer 4 seconds
            public void actionPerformed(ActionEvent e) {
            	
            	audioClip2.start();                 
            }
        }); 
		timer2.start();
		timer1 = new Timer(3740, new ActionListener(){// Timer 4 seconds
            public void actionPerformed(ActionEvent e) {
            	try {
            	
            		
					Game();
					
				} catch (InterruptedException e1) {
				}
            }
        }); 
		timer.stop();
		timer1.start();	
	}
	public static JLabel label = new JLabel("");
	public static JLabel lblNewLabel_1 = new JLabel("");
	public static JPanel panel = new JPanel();
	public static void Game() throws InterruptedException{
		Health = 4;
		loseCount = 0;
		WinCount = 0;
		timer1.stop();	
	
		timer3 = new Timer(4000, new ActionListener(){// Timer 4 seconds
            public void actionPerformed(ActionEvent e) {
            	int EventNum = event.nextInt(100) + 1;
            	if (EventNum <=100 && EventNum >= 70){
            		
            	EventStatic();
            	}
            	if (EventNum <= 69 && EventNum >= 59){
            	EventFlash();
            	}

            }
        }); 
		timer3.start();
		Keyboard();
		frame.setBounds(100, 100, 770, 450);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		frame.getContentPane().setLayout(null);
		//
		JLabel Pic = new JLabel("");
		Pic.setForeground(new Color(255, 255, 240));
		Pic.setIcon(new ImageIcon("D:\\workspace\\HangMan RST\\scarypic.jpg"));
		Pic.setBounds(0, -1000, 770, 450);
		
		if (Correct == 9){
			Win();
		}
		lblNewLabel_1.setForeground(new Color(255, 255, 240));
		lblNewLabel_1.setIcon(new ImageIcon(pictures[0][0]));
		lblNewLabel_1.setBounds(76, 70, 195, 282);
		frame.getContentPane().add(lblNewLabel_1);
		
		
		String HealthBar = "D:\\workspace\\HangMan RST\\HealthBar4.jpg";
		label.setIcon(new ImageIcon(HealthBar));
		label.setBounds(10, 70, 67, 282);
		frame.getContentPane().add(label);
		
		
		panel.setBackground(new Color(0, 0, 0));
		panel.setSize(454, 70);
		panel.setLocation(302, 94);
		frame.getContentPane().add(panel);
		
		//
		
		frame.setVisible(true);
		 
		}
		public static void EventStatic(){
			int y = 11;
			JLabel Gif = new JLabel("");
    		Gif.setForeground(new Color(255, 255, 240));
    		Gif.setIcon(new ImageIcon("D:\\workspace\\HangMan RST\\static.gif"));
    		Gif.setBounds(0, y, 1000, 1000);
    		frame.getContentPane().add(Gif);	
			timer4 = new Timer(800, new ActionListener(){// Timer 4 seconds
	            public void actionPerformed(ActionEvent e) {
	            	Gif.setBounds(0, -10000, 195, 242);
	            }
	            
	        }); 
			timer4.start();
			
		}
		public static void EventFlash(){
			int y = 50;
			JLabel Pic = new JLabel("");
    		Pic.setForeground(new Color(255, 255, 240));
    		Pic.setIcon(new ImageIcon("D:\\workspace\\HangMan RST\\scarypic.jpg"));
    		Pic.setBounds(0, y, 770, 450);
    		frame.getContentPane().add(Pic);	
			timer5 = new Timer(1000, new ActionListener(){// Timer 4 seconds
	            public void actionPerformed(ActionEvent e) {
	            	
	            	Pic.setBounds(0, -10000, 195, 242);
	            	if (GameMode == 4){
	            		System.exit(0);
	            	}
	            }
	            
	        }); 
			File audioFile = new File("D:/workspace/HangMan RST/scream2.wav");
		   	 
	        try {
	            AudioInputStream audioStream = AudioSystem.getAudioInputStream(audioFile);
	 
	            AudioFormat format = audioStream.getFormat();
	 
	            DataLine.Info info = new DataLine.Info(Clip.class, format);
	 
	            Clip audioClip1 = (Clip) AudioSystem.getLine(info);
	            audioClip2 = audioClip1;
	            audioClip2.open(audioStream);
	             
	            
	            
	             
	        } catch (UnsupportedAudioFileException ex) {
	            System.out.println("The specified audio file is not supported.");
	            ex.printStackTrace();
	        } catch (LineUnavailableException ex) {
	            System.out.println("Audio line for playing back is unavailable.");
	            ex.printStackTrace();
	        } catch (IOException ex) {
	            System.out.println("Error playing the audio file.");
	            ex.printStackTrace();
	        }
	        audioClip2.start();
			timer5.start();
		}
		public static void CharPicChooser(){
			frame.getContentPane().setBackground(Color.BLACK);
			frame.setBackground(Color.WHITE);
			frame.setBounds(100, 100, 770, 450);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setResizable(false);
			frame.getContentPane().setLayout(null);
			
			JButton btnVanillaMode = new JButton("Vanilla Mode");
			btnVanillaMode.setBounds(99, 286, 107, 23);
			frame.getContentPane().add(btnVanillaMode);
			btnVanillaMode.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Charecter = 0;
					if (GameMode == 2){
						ModeChooser();
					}
					if (GameMode == 3){
						Multi();
					}
				}
			});
			JButton btnChristmas = new JButton("Skeleton");
			btnChristmas.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Charecter = 2;
					if (GameMode == 2){
						ModeChooser();
					}
					if (GameMode == 3){
						Multi();
					}
				}
			});
			btnChristmas.setBounds(419, 286, 107, 23);
			frame.getContentPane().add(btnChristmas);
			
			JButton btnCandy = new JButton("Snow Man");
			btnCandy.setBounds(585, 286, 107, 23);
			frame.getContentPane().add(btnCandy);
			btnCandy.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Charecter = 3;
					if (GameMode == 2){
						ModeChooser();
					}
					if (GameMode == 3){
						Multi();
					}
				}
			});
			
			JButton btnCompSci = new JButton("Pepe");
			btnCompSci.setBounds(258, 286, 107, 23);
			frame.getContentPane().add(btnCompSci);
			btnCompSci.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Charecter = 1;
					if (GameMode == 2){
						ModeChooser();
					}
					if (GameMode == 3){
					Multi();
					}
				}
			});
			JLabel lblNewLabel = new JLabel("New label");
			lblNewLabel.setIcon(new ImageIcon("D:\\workspace\\HangMan RST\\HumanNormal.jpg"));
			lblNewLabel.setBounds(35, 91, 188, 184);
			frame.getContentPane().add(lblNewLabel);
			
			JLabel lblNewLabel_1 = new JLabel("New label");
			lblNewLabel_1.setIcon(new ImageIcon("D:\\workspace\\HangMan RST\\pepe1.jpg"));
			lblNewLabel_1.setBounds(245, 79, 139, 196);
			frame.getContentPane().add(lblNewLabel_1);
			
			JLabel lblNewLabel_2 = new JLabel("New label");
			lblNewLabel_2.setIcon(new ImageIcon("D:\\workspace\\HangMan RST\\Skeleton1.jpg"));
			lblNewLabel_2.setBounds(403, 79, 139, 196);
			frame.getContentPane().add(lblNewLabel_2);
			
			JLabel lblNewLabel_3 = new JLabel("New label");
			lblNewLabel_3.setIcon(new ImageIcon("D:\\workspace\\HangMan RST\\Snowman1.jpg"));
			lblNewLabel_3.setBounds(552, 91, 159, 184);
			frame.getContentPane().add(lblNewLabel_3);
			
			

		
			
			
			
			
		}
		public static void ModeChooser(){
			
			frame.getContentPane().removeAll();
			frame.getContentPane().repaint();
			frame.setBounds(100, 100, 770, 450);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setResizable(false);
			frame.getContentPane().setLayout(null);
			
			JButton btnVanillaMode = new JButton("Vanilla Mode");
			btnVanillaMode.setBounds(95, 138, 107, 23);
			frame.getContentPane().add(btnVanillaMode);
			btnVanillaMode.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
				FunMode();
				}
			});
			JButton btnChristmas = new JButton("Christmas");
			btnChristmas.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
				Gamemode = 2;
				FunMode();
				}
			});
			btnChristmas.setBounds(412, 138, 107, 23);
			frame.getContentPane().add(btnChristmas);
			
			JButton btnCandy = new JButton("Candy");
			btnCandy.setBounds(565, 138, 107, 23);
			frame.getContentPane().add(btnCandy);
			btnCandy.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
				Gamemode = 3;
				FunMode();
				}
			});
			
			JButton btnCompSci = new JButton("Comp Sci");
			btnCompSci.setBounds(253, 138, 107, 23);
			frame.getContentPane().add(btnCompSci);
			btnCompSci.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
				Gamemode = 1;
				FunMode();
				}
			});
			
			JTextField txtChooseAMode = new JTextField();
			txtChooseAMode.setBackground(Color.BLACK);
			txtChooseAMode.setHorizontalAlignment(SwingConstants.CENTER);
			txtChooseAMode.setFont(new Font("Tarzan", Font.ITALIC, 40));
			txtChooseAMode.setForeground(new Color(255, 0, 255));
			txtChooseAMode.setText("Choose a mode!");
			txtChooseAMode.setEditable(false);
			txtChooseAMode.setBounds(0, 0, 764, 421);
			frame.getContentPane().add(txtChooseAMode);
			txtChooseAMode.setColumns(10);

		}
		public static void FunMode(){
			Health = 4;
			loseCount = 0;
			WinCount = 0;
			
			Keyboard();
			frame.setBounds(100, 100, 770, 450);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setResizable(false);
			frame.getContentPane().setLayout(null);
			if (Correct == 10){
				//
			}
			lblNewLabel_1.setForeground(new Color(255, 255, 240));
			lblNewLabel_1.setIcon(new ImageIcon(pictures[Charecter][0]));
			lblNewLabel_1.setBounds(76, 70, 195, 282);
			frame.getContentPane().add(lblNewLabel_1);
			
			
			String HealthBar = "D:\\workspace\\HangMan RST\\HealthBar4.jpg";
			label.setIcon(new ImageIcon(HealthBar));
			label.setBounds(10, 70, 67, 282);
			frame.getContentPane().add(label);
			panel.setBackground(new Color(0, 0, 0));
			panel.setSize(454, 70);
			panel.setLocation(302, 94);
			frame.getContentPane().add(panel);
			
			
			//
			
			JButton Scoreboard = new JButton("Score: " + Wins +" - " + Loses);
			Scoreboard.setFont(new Font("Tahoma", Font.PLAIN, 16));
			Scoreboard.setOpaque(false);
			Scoreboard.setContentAreaFilled(false);
			Scoreboard.setBorderPainted(false);
			Scoreboard.setForeground(Color.YELLOW);
			Scoreboard.setBounds(600, 20, 150, 23);
			Scoreboard.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					ModeChooser();
					}
				});
			frame.getContentPane().add(Scoreboard);
			frame.setVisible(true);
			
		}
		public static void Multi(){
			Health = 4;
			
			Keyboard();
			frame.setBounds(100, 100, 770, 450);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setResizable(false);
			frame.getContentPane().setLayout(null);
			if (Correct == 10){
				//
			}
			lblNewLabel_1.setForeground(new Color(255, 255, 240));
			lblNewLabel_1.setIcon(new ImageIcon(pictures[Charecter][0]));
			lblNewLabel_1.setBounds(76, 70, 195, 282);
			frame.getContentPane().add(lblNewLabel_1);
			
			
			String HealthBar = "D:\\workspace\\HangMan RST\\HealthBar4.jpg";
			label.setIcon(new ImageIcon(HealthBar));
			label.setBounds(10, 70, 67, 282);
			frame.getContentPane().add(label);
			panel.setBackground(new Color(0, 0, 0));
			panel.setSize(454, 70);
			panel.setLocation(302, 94);
			frame.getContentPane().add(panel);
			
			
			//
			
			JButton Scoreboard = new JButton("Score: " + Wins +" - " + Loses);
			Scoreboard.setFont(new Font("Tahoma", Font.PLAIN, 16));
			Scoreboard.setOpaque(false);
			Scoreboard.setContentAreaFilled(false);
			Scoreboard.setBorderPainted(false);
			Scoreboard.setForeground(Color.YELLOW);
			Scoreboard.setBounds(600, 20, 150, 23);
			Scoreboard.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					ModeChooser();
					}
				});
			frame.setVisible(true);
		}
		public static void Health(){
        
			Health--;
        	if(Health == 3){
				label.setIcon(new ImageIcon("D:\\workspace\\HangMan RST\\HealthBar3.jpg"));
				label.setBounds(10, 70, 67, 282);
				frame.getContentPane().add(label);
				//
				lblNewLabel_1.setForeground(new Color(255, 255, 240));
				lblNewLabel_1.setIcon(new ImageIcon(pictures[Charecter][1]));
				lblNewLabel_1.setBounds(76, 70, 195, 282);
				frame.getContentPane().add(lblNewLabel_1);
			}
			if(Health == 2){
				label.setIcon(new ImageIcon("D:\\workspace\\HangMan RST\\HealthBar2.jpg"));
				label.setBounds(10, 70, 67, 282);
				frame.getContentPane().add(label);
				//
				lblNewLabel_1.setForeground(new Color(255, 255, 240));
				lblNewLabel_1.setIcon(new ImageIcon(pictures[Charecter][2]));
				lblNewLabel_1.setBounds(76, 70, 195, 282);
				frame.getContentPane().add(lblNewLabel_1);
			}
			if(Health == 1){
				label.setIcon(new ImageIcon("D:\\workspace\\HangMan RST\\HealthBar1.jpg"));
				label.setBounds(10, 70, 67, 282);
				frame.getContentPane().add(label);
				//
				lblNewLabel_1.setForeground(new Color(255, 255, 240));
				lblNewLabel_1.setIcon(new ImageIcon(pictures[Charecter][3]));
				lblNewLabel_1.setBounds(76, 70, 195, 282);
				frame.getContentPane().add(lblNewLabel_1);
			}
			if(Health == 0){
				label.setIcon(new ImageIcon("D:\\workspace\\HangMan RST\\HealthBar0.jpg"));
				label.setBounds(10, 70, 67, 282);
				frame.getContentPane().add(label);
				JOptionPane.showMessageDialog(null, "YOU LOSE. YOU LOSE. DEATH.", "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
				if (GameMode == 2){
				Loses++;
				stats[2] = Loses;
				try{
				    PrintWriter writer = new PrintWriter("stats.txt");
				    writer.println(stats[0]);
				    writer.println(stats[1]);
				    writer.println(stats[2]);
				    writer.close();
				} catch (IOException e) {
				}
				FunMode();
				}
				if (GameMode == 1){					
					End();
				}
				
			}
			
			System.out.println(Health);
        }
		public static void End(){
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
			}
			frame.getContentPane().removeAll();
			frame.getContentPane().repaint();
			frame.getContentPane().setBackground(Color.BLACK);
			GameMode = 4;
			EventFlash();
		}
		public static void WinAdd(){
			Wins++;
			stats[1] = Wins;
			try{
			    PrintWriter writer = new PrintWriter("stats.txt");
			    writer.println(stats[0]);
			    writer.println(stats[1]);
			    writer.println(stats[2]);
			    writer.close();
			} catch (IOException e) {
			   // do something
			}
			
			FunMode();

		}
		public static String word;
		public static int wordlength = 0;
		public static void Keyboard(){
			WinCount = 0;
			frame.getContentPane().removeAll();
			frame.getContentPane().repaint();
			frame.getContentPane().setBackground(Color.BLACK);
			panel.removeAll();
			
			words[0][0] = "death"; words[0][1] = "murder";  words[0][2] = "ghost"; words[0][3] = "haunted"; words[0][4] = "blood";
			words[0][5] = "horror"; words[0][6] = "skeleton";  words[0][7] = "murder";  words[0][8] = "ghoul";  words[0][9] = "sociopath";
			words[0][10] = "necromancer"; words[0][11] = "occult"; words[0][12] = "zombie"; words[0][13] = "mystic"; words[0][14] = "phantom";
			words[0][15] = "eerie"; words[0][16] = "ghastly"; words[0][17] = "conjueror"; words[0][18] = "spirit";
			//CompSci
			words[1][0] = "java"; words[1][1] = "compiler";  words[1][2] = "pseudocode"; words[1][3] = "loop"; words[1][4] = "fileio";
			words[1][5] = "algorithm"; words[1][6] = "programmer";  words[1][7] = "abstract";  words[1][8] = "jframe";  words[1][9] = "hacker";
			words[1][10] = "linux"; words[1][11] = "python"; words[1][12] = "pentester"; words[1][13] = "metasploit"; words[1][14] = "malware";
			words[1][15] = "csharp"; words[1][16] = "ide"; words[1][17] = "developer"; words[1][18] = "software";
			//Christmas
			words[2][0] = "snow"; words[2][1] = "stockings";  words[2][2] = "reindeer"; words[2][3] = "advent"; words[2][4] = "chimney";
			words[2][5] = "fruitcakes"; words[2][6] = "festival";  words[2][7] = "elves";  words[2][8] = "gifts";  words[2][9] = "santaclaus";
			words[2][10] = "rudoplh"; words[2][11] = "mistletoe"; words[2][12] = "miracle"; words[2][13] = "yuletide"; words[2][14] = "icicles";
			words[2][15] = "nice"; words[2][16] = "naughty"; words[2][17] = "jolly"; words[2][18] = "holiday";
			//Candy
			words[3][0] = "chocolate"; words[3][1] = "lolipop";  words[3][2] = "jellybean"; words[3][3] = "gummybear"; words[3][4] = "gummyworm";
			words[3][5] = "hubbabubba"; words[3][6] = "gumdrop";  words[3][7] = "jollyrancher";  words[3][8] = "hardcandy";  words[3][9] = "marshmellow";
			words[3][10] = "sucker"; words[3][11] = "sugar"; words[3][12] = "slushie"; words[3][13] = "sourstring"; words[3][14] = "peep";
			words[3][15] = "aids"; words[3][16] = "calories"; words[3][17] = "diabetes"; words[3][18] = "syrup";
			
			
			pictures[0][0] = "D:\\workspace\\HangMan RST\\HumanNormal.jpg"; pictures[0][1] = "D:\\workspace\\HangMan RST\\Human2.jpg";
			pictures[0][2] = "D:\\workspace\\HangMan RST\\Human3.jpg"; pictures[0][3] = "D:\\workspace\\HangMan RST\\Human4.jpg";
			
			pictures[1][0] = "D:\\workspace\\HangMan RST\\pepe1.jpg"; pictures[1][1] = "D:\\workspace\\HangMan RST\\pepe2.jpg";
			pictures[1][2] = "D:\\workspace\\HangMan RST\\pepe3.jpg"; pictures[1][3] = "D:\\workspace\\HangMan RST\\pepe4.jpg";

			pictures[2][0] = "D:\\workspace\\HangMan RST\\Skeleton1.jpg"; pictures[2][1] = "D:\\workspace\\HangMan RST\\Skeleton2.jpg";
			pictures[2][2] = "D:\\workspace\\HangMan RST\\Skeleton3.jpg"; pictures[2][3] = "D:\\workspace\\HangMan RST\\Skeleton4.jpg";
			
			pictures[3][0] = "D:\\workspace\\HangMan RST\\Snowman1.jpg"; pictures[3][1] = "D:\\workspace\\HangMan RST\\Snowman2.jpg";
			pictures[3][2] = "D:\\workspace\\HangMan RST\\Snowman3.jpg"; pictures[3][3] = "D:\\workspace\\HangMan RST\\Snowman4.jpg";
			
			int  n = rand.nextInt(18) + 0;
			word = words[0][n];
			if (GameMode == 3){
				Ask();
				
			}
			
			wordlength = word.length();
			
			String[] wordF = new String[wordlength];
			int counter= 0;
			while (counter != wordlength){		
				char wordin = word.charAt(counter);
				wordF[counter] =  String.valueOf(wordin);	
				counter++;
			}
			
			counter = 0;
			JButton[] button = new JButton[wordlength];
			while (counter != wordlength){		
				button[counter] = new JButton(wordF[counter]);
				counter++;
			}
			counter = 0;
			while( counter != wordlength){
				panel.add(button[counter]);
				button[counter].setOpaque(false);
				button[counter].setContentAreaFilled(false);
				button[counter].setForeground(Color.BLACK);
				counter++;
			}
			
			//
			JButton btnA = new JButton("A");
			btnA.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btnA.setBounds(302, 244, 48, 23);
			frame.getContentPane().add(btnA);
			btnA.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e){
					int NewCounter = 0; 
					int NewWordlength = wordlength;
					int loseCount = 0;
					while(NewCounter != NewWordlength){
						if(wordF[NewCounter].equals("a")){
							button[NewCounter].setForeground(new Color(165, 42, 42));
							WinCount++;
						}
						if(!wordF[NewCounter].equals("a")){
							loseCount++;
						}
						
					NewCounter++;
					if (WinCount == NewWordlength){
						loseCount = 0;
						Correct++;
						if (GameMode == 1){
						try {
							JOptionPane.showMessageDialog(null, "Correct!", "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
							Game();
						} catch (InterruptedException e1) {
						
							}
						}
						if (GameMode == 2){
							WinAdd();	
						}
						if (GameMode == 3){
							
							 wordlength = 1;Multi();	
						}
					}
					if(loseCount == NewWordlength){
						loseCount = 0;
						Health();
					}
					}
					
				btnA.setEnabled(false);	
				}
			});	

			JButton btnB = new JButton("B");
			btnB.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btnB.setBounds(360, 244, 48, 23);
			frame.getContentPane().add(btnB);
			btnB.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int NewCounter = 0; 
					int NewWordlength = wordlength;
					int loseCount = 0;
					while(NewCounter != NewWordlength){
						if(wordF[NewCounter].equals("b")){
							button[NewCounter].setForeground(new Color(165, 42, 42));
							WinCount++;
						}
						if(!wordF[NewCounter].equals("b")){
							loseCount++;
						}
						
						NewCounter++;
						if (WinCount == NewWordlength){
							loseCount = 0;
							Correct++;
							if (GameMode == 1){
							try {
								JOptionPane.showMessageDialog(null, "Correct!", "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
								Game();
							} catch (InterruptedException e1) {
							
								}
							}
							if (GameMode == 2){
								WinAdd();
							}
							if (GameMode == 3){
								 wordlength = 1;Multi();	
							}
						}
						if(loseCount == NewWordlength){
							loseCount = 0;
							Health();
						}
						}
					btnB.setEnabled(false);	
					}
				});	
				
			JButton btnC = new JButton("C");
			btnC.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btnC.setBounds(418, 244, 48, 23);
			frame.getContentPane().add(btnC);
			btnC.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int NewCounter = 0; 
					int NewWordlength = wordlength;
					int loseCount = 0;
					while(NewCounter != NewWordlength){
						if(wordF[NewCounter].equals("c")){
							button[NewCounter].setForeground(new Color(165, 42, 42));
							WinCount++;
						}
						if(!wordF[NewCounter].equals("c")){
							loseCount++;
						}
						NewCounter++;
						if (WinCount == NewWordlength){
							loseCount = 0;
							Correct++;
							if (GameMode == 1){
							try {
								JOptionPane.showMessageDialog(null, "Correct!", "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
								Game();
							} catch (InterruptedException e1) {
							
								}
							}
							if (GameMode == 2){
								WinAdd();
								
							}
							if (GameMode == 3){
								 wordlength = 1;Multi();	
							}
						}
						if(loseCount == NewWordlength){
							loseCount = 0;
							Health();
						}		
						}
					btnC.setEnabled(false);	
					}
				});	
			JButton btnD = new JButton("D");
			btnD.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btnD.setBounds(476, 244, 48, 23);
			frame.getContentPane().add(btnD);
			btnD.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int NewCounter = 0; 
					int NewWordlength = wordlength;
					int loseCount = 0;
					while(NewCounter != NewWordlength){
						if(wordF[NewCounter].equals("d")){
							button[NewCounter].setForeground(new Color(165, 42, 42));
							WinCount++;
						}
						if(!wordF[NewCounter].equals("d")){
							loseCount++;
						}
						NewCounter++;
						if (WinCount == NewWordlength){
							loseCount = 0;
							Correct++;
							if (GameMode == 1){
							try {
								JOptionPane.showMessageDialog(null, "Correct!", "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
								Game();
							} catch (InterruptedException e1) {
							
								}
							}
							if (GameMode == 2){
								WinAdd();

								
							}
							if (GameMode == 3){
								 wordlength = 1;Multi();	
							}
						}
						if(loseCount == NewWordlength){
							loseCount = 0;
							Health();
						}
						}
					btnD.setEnabled(false);	
					}
				});	
			
			
			JButton btnE = new JButton("E");
			btnE.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btnE.setBounds(534, 244, 48, 23);
			frame.getContentPane().add(btnE);
			btnE.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int NewCounter = 0; 
					int NewWordlength = wordlength;
					int loseCount = 0;
					while(NewCounter != NewWordlength){
						if(wordF[NewCounter].equals("e")){
							button[NewCounter].setForeground(new Color(165, 42, 42));
							WinCount++;
						}
						if(!wordF[NewCounter].equals("e")){
							loseCount++;
						}
						NewCounter++;
						if (WinCount == NewWordlength){
							loseCount = 0;
							Correct++;
							if (GameMode == 1){
							try {
								JOptionPane.showMessageDialog(null, "Correct!", "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
								Game();
							} catch (InterruptedException e1) {
							
								}
							}
							if (GameMode == 2){
								WinAdd();

								
							}
							if (GameMode == 3){
								 wordlength = 1;Multi();	
							}
						}
						if(loseCount == NewWordlength){
							loseCount = 0;
							Health();
						}
						}
					btnE.setEnabled(false);	
					}
				});	
			JButton btnF = new JButton("F");
			btnF.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btnF.setBounds(592, 244, 48, 23);
			frame.getContentPane().add(btnF);
			btnF.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int NewCounter = 0; 
					int NewWordlength = wordlength;
					int loseCount = 0;
					while(NewCounter != NewWordlength){
						if(wordF[NewCounter].equals("f")){
							button[NewCounter].setForeground(new Color(165, 42, 42));
							WinCount++;
						}
						if(!wordF[NewCounter].equals("f")){
							loseCount++;
						}
						NewCounter++;
						if (WinCount == NewWordlength){
							loseCount = 0;
							Correct++;
							if (GameMode == 1){
							try {
								JOptionPane.showMessageDialog(null, "Correct!", "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
								Game();
							} catch (InterruptedException e1) {
							
								}
							}
							if (GameMode == 2){
								WinAdd();

								
							}
							if (GameMode == 3){
								 wordlength = 1;Multi();	
							}
						}
						if(loseCount == NewWordlength){
							loseCount = 0;
							Health();
						}
						}
					btnF.setEnabled(false);	
					}
				});	
			JButton btnG = new JButton("G");
			btnG.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btnG.setBounds(650, 244, 48, 23);
			frame.getContentPane().add(btnG);
			btnG.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int NewCounter = 0; 
					int NewWordlength = wordlength;
					int loseCount = 0;
					while(NewCounter != NewWordlength){
						if(wordF[NewCounter].equals("g")){
							button[NewCounter].setForeground(new Color(165, 42, 42));
							WinCount++;
						}
						if(!wordF[NewCounter].equals("g")){
							loseCount++;
						}
						NewCounter++;
						if (WinCount == NewWordlength){
							loseCount = 0;
							Correct++;
							if (GameMode == 1){
							try {
								JOptionPane.showMessageDialog(null, "Correct!", "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
								Game();
							} catch (InterruptedException e1) {
							
								}
							}
							if (GameMode == 2){
								WinAdd();

								
							}
							if (GameMode == 3){
								 wordlength = 1;Multi();	
							}
						}
						if(loseCount == NewWordlength){
							loseCount = 0;
							Health();
						}
						}
					btnG.setEnabled(false);	
					}
				});	
			JButton btnH = new JButton("H");
			btnH.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btnH.setBounds(708, 244, 48, 23);
			frame.getContentPane().add(btnH);
			btnH.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int NewCounter = 0; 
					int NewWordlength = wordlength;
					int loseCount = 0;
					while(NewCounter != NewWordlength){
						if(wordF[NewCounter].equals("h")){
							button[NewCounter].setForeground(new Color(165, 42, 42));
							WinCount++;
						}
						if(!wordF[NewCounter].equals("h")){
							loseCount++;
						}
						NewCounter++;
						if (WinCount == NewWordlength){
							loseCount = 0;
							Correct++;
							if (GameMode == 1){
							try {
								JOptionPane.showMessageDialog(null, "Correct!", "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
								Game();
							} catch (InterruptedException e1) {
							
								}
							}
							if (GameMode == 2){
								WinAdd();

								
							}
							if (GameMode == 3){
								 wordlength = 1;Multi();	
							}
						}
						if(loseCount == NewWordlength){
							loseCount = 0;
							Health();
						}
						}
					btnH.setEnabled(false);	
					}
				});	
			JButton btnI = new JButton("I");
			btnI.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btnI.setBounds(331, 278, 48, 23);
			frame.getContentPane().add(btnI);
			btnI.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int NewCounter = 0; 
					int NewWordlength = wordlength;
					int loseCount = 0;
					while(NewCounter != NewWordlength){
						if(wordF[NewCounter].equals("i")){
							button[NewCounter].setForeground(new Color(165, 42, 42));
							WinCount++;
						}
						if(!wordF[NewCounter].equals("i")){
							loseCount++;
						}
						NewCounter++;
						if (WinCount == NewWordlength){
							loseCount = 0;
							Correct++;
							if (GameMode == 1){
							try {
								JOptionPane.showMessageDialog(null, "Correct!", "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
								Game();
							} catch (InterruptedException e1) {
							
								}
							}
							if (GameMode == 2){
								WinAdd();

								
							}
							if (GameMode == 3){
								 wordlength = 1;Multi();	
							}
						}
						if(loseCount == NewWordlength){
							loseCount = 0;
							Health();	
						}
						}
					btnI.setEnabled(false);	
					}
				});	
			JButton btnJ = new JButton("J");
			btnJ.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btnJ.setBounds(389, 278, 48, 23);
			frame.getContentPane().add(btnJ);
			btnJ.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int NewCounter = 0; 
					int NewWordlength = wordlength;
					int loseCount = 0;
					while(NewCounter != NewWordlength){
						if(wordF[NewCounter].equals("j")){
							button[NewCounter].setForeground(new Color(165, 42, 42));
							WinCount++;
						}
						if(!wordF[NewCounter].equals("j")){
							loseCount++;
						}
						NewCounter++;
						if (WinCount == NewWordlength){
							loseCount = 0;
							Correct++;
							if (GameMode == 1){
							try {
								JOptionPane.showMessageDialog(null, "Correct!", "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
								Game();
							} catch (InterruptedException e1) {
							
								}
							}
							if (GameMode == 2){
								WinAdd();

								
							}
							if (GameMode == 3){
								 wordlength = 1;Multi();	
							}
						}
						if(loseCount == NewWordlength){
							loseCount = 0;
							Health();
						}
						}
					btnJ.setEnabled(false);	
					}
				});	
			JButton btnK = new JButton("K");
			btnK.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btnK.setBounds(447, 278, 48, 23);
			frame.getContentPane().add(btnK);
			btnK.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int NewCounter = 0; 
					int NewWordlength = wordlength;
					int loseCount = 0;
					while(NewCounter != NewWordlength){
						if(wordF[NewCounter].equals("k")){
							button[NewCounter].setForeground(new Color(165, 42, 42));
							WinCount++;
						}
						if(!wordF[NewCounter].equals("k")){
							loseCount++;
						}
						NewCounter++;
						if (WinCount == NewWordlength){
							loseCount = 0;
							Correct++;
							if (GameMode == 1){
							try {
								JOptionPane.showMessageDialog(null, "Correct!", "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
								Game();
							} catch (InterruptedException e1) {
							
								}
							}
							if (GameMode == 2){
								WinAdd();

								
							}
							if (GameMode == 3){
								 wordlength = 1;Multi();	
							}
						}
						if(loseCount == NewWordlength){
							loseCount = 0;
							Health();
						}
						}
					btnK.setEnabled(false);	
					}
				});	
			JButton btnL = new JButton("L");
			btnL.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btnL.setBounds(505, 278, 48, 23);
			frame.getContentPane().add(btnL);
			btnL.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int NewCounter = 0; 
					int NewWordlength = wordlength;
					int loseCount = 0;
					while(NewCounter != NewWordlength){
						if(wordF[NewCounter].equals("l")){
							button[NewCounter].setForeground(new Color(165, 42, 42));
							WinCount++;
						}
						if(!wordF[NewCounter].equals("l")){
							loseCount++;
						}
						NewCounter++;
						if (WinCount == NewWordlength){
							loseCount = 0;
							Correct++;
							if (GameMode == 1){
							try {
								JOptionPane.showMessageDialog(null, "Correct!", "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
								Game();
							} catch (InterruptedException e1) {
							
								}
							}
							if (GameMode == 2){
								WinAdd();

								
							}
							if (GameMode == 3){
								 wordlength = 1;Multi();	
							}
						}
						if(loseCount == NewWordlength){
							loseCount = 0;
							Health();	
						}
						}
					btnL.setEnabled(false);	
					}
				});	
			JButton btnM = new JButton("M");
			btnM.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btnM.setBounds(563, 278, 48, 23);
			frame.getContentPane().add(btnM); 
			btnM.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int NewCounter = 0; 
					int NewWordlength = wordlength;
					int loseCount = 0;
					while(NewCounter != NewWordlength){
						if(wordF[NewCounter].equals("m")){
							button[NewCounter].setForeground(new Color(165, 42, 42));
							WinCount++;
						}
						if(!wordF[NewCounter].equals("m")){
							loseCount++;
						}
						NewCounter++;
						if (WinCount == NewWordlength){
							loseCount = 0;
							Correct++;
							if (GameMode == 1){
							try {
								JOptionPane.showMessageDialog(null, "Correct!", "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
								Game();
							} catch (InterruptedException e1) {
							
								}
							}
							if (GameMode == 2){
								WinAdd();

								
							}
							if (GameMode == 3){
								 wordlength = 1;Multi();	
							}
						}
						if(loseCount == NewWordlength){
							loseCount = 0;
							Health();	
						}
						}
					btnM.setEnabled(false);	
					}
				});	
			JButton btnN = new JButton("N");
			btnN.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btnN.setBounds(621, 278, 48, 23);
			frame.getContentPane().add(btnN);
			btnN.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int NewCounter = 0; 
					int NewWordlength = wordlength;
					int loseCount = 0;
					while(NewCounter != NewWordlength){
						if(wordF[NewCounter].equals("n")){
							button[NewCounter].setForeground(new Color(165, 42, 42));
							WinCount++;
						}
						if(!wordF[NewCounter].equals("n")){
							loseCount++;
						}
						NewCounter++;
						if (WinCount == NewWordlength){
							loseCount = 0;
							Correct++;
							if (GameMode == 1){
							try {
								JOptionPane.showMessageDialog(null, "Correct!", "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
								Game();
							} catch (InterruptedException e1) {
							
								}
							}
							if (GameMode == 2){
								WinAdd();

								
							}
							if (GameMode == 3){
								 wordlength = 1;Multi();	
							}
						}
						if(loseCount == NewWordlength){
							loseCount = 0;
							Health();
						}
						}
					btnN.setEnabled(false);	
					}
				});	
			JButton btnO = new JButton("O");
			btnO.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btnO.setBounds(679, 278, 48, 23);
			frame.getContentPane().add(btnO);
			btnO.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int NewCounter = 0; 
					int NewWordlength = wordlength;
					int loseCount = 0;
					while(NewCounter != NewWordlength){
						if(wordF[NewCounter].equals("o")){
							button[NewCounter].setForeground(new Color(165, 42, 42));
							WinCount++;
						}
						if(!wordF[NewCounter].equals("o")){
							loseCount++;
						}
						NewCounter++;
						if (WinCount == NewWordlength){
							loseCount = 0;
							Correct++;
							if (GameMode == 1){
							try {
								JOptionPane.showMessageDialog(null, "Correct!", "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
								Game();
							} catch (InterruptedException e1) {
							
								}
							}
							if (GameMode == 2){
								WinAdd();

								
							}
							if (GameMode == 3){
								 wordlength = 1;Multi();	
							}
						}
						if(loseCount == NewWordlength){
							loseCount = 0;
							Health();	
						}
						}
					btnO.setEnabled(false);	
					}
				});	
			JButton btnP = new JButton("P");
			btnP.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btnP.setBounds(360, 312, 48, 23);
			frame.getContentPane().add(btnP);
			btnP.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int NewCounter = 0; 
					int NewWordlength = wordlength;
					int loseCount = 0;
					while(NewCounter != NewWordlength){
						if(wordF[NewCounter].equals("p")){
							button[NewCounter].setForeground(new Color(165, 42, 42));
							WinCount++;
						}
						if(!wordF[NewCounter].equals("p")){
							loseCount++;
						}
						NewCounter++;
						if (WinCount == NewWordlength){
							loseCount = 0;
							Correct++;
							if (GameMode == 1){
							try {
								JOptionPane.showMessageDialog(null, "Correct!", "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
								Game();
							} catch (InterruptedException e1) {
							
								}
							}
							if (GameMode == 2){
								WinAdd();

								
							}
							if (GameMode == 3){
								 wordlength = 1;Multi();	
							}
						}
						if(loseCount == NewWordlength){
							loseCount = 0;
							Health();	
						}
						}
					btnP.setEnabled(false);	
					}
				});	
			JButton btnQ = new JButton("Q");
			btnQ.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btnQ.setBounds(418, 312, 48, 23);
			frame.getContentPane().add(btnQ);
			btnQ.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int NewCounter = 0; 
					int NewWordlength = wordlength;
					int loseCount = 0;
					while(NewCounter != NewWordlength){
						if(wordF[NewCounter].equals("q")){
							button[NewCounter].setForeground(new Color(165, 42, 42));
							WinCount++;
						}
						if(!wordF[NewCounter].equals("q")){
							loseCount++;
						}
						NewCounter++;
						if (WinCount == NewWordlength){
							loseCount = 0;
							Correct++;
							if (GameMode == 1){
							try {
								JOptionPane.showMessageDialog(null, "Correct!", "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
								Game();
							} catch (InterruptedException e1) {
							
								}
							}
							if (GameMode == 2){
								WinAdd();

								
							}
							if (GameMode == 3){
								 wordlength = 1;Multi();	
							}
						}
						if(loseCount == NewWordlength){
							loseCount = 0;
							Health();	
						}
						}
					btnQ.setEnabled(false);	
					}
				});	
			JButton btnR = new JButton("R");
			btnR.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btnR.setBounds(476, 312, 48, 23);
			frame.getContentPane().add(btnR);
			btnR.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int NewCounter = 0; 
					int NewWordlength = wordlength;
					int loseCount = 0;
					while(NewCounter != NewWordlength){
						if(wordF[NewCounter].equals("r")){
							button[NewCounter].setForeground(new Color(165, 42, 42));
							WinCount++;
						}
						if(!wordF[NewCounter].equals("r")){
							loseCount++;
						}
						NewCounter++;
						if (WinCount == NewWordlength){
							loseCount = 0;
							Correct++;
							if (GameMode == 1){
							try {
								JOptionPane.showMessageDialog(null, "Correct!", "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
								Game();
							} catch (InterruptedException e1) {
							
								}
							}
							if (GameMode == 2){
								WinAdd();

								
							}
							if (GameMode == 3){
								 wordlength = 1;Multi();	
							}
						}
						if(loseCount == NewWordlength){
							loseCount = 0;
							Health();	
						}
						}
					btnR.setEnabled(false);	
					}
				});	
			JButton btnS = new JButton("S");
			btnS.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btnS.setBounds(534, 312, 48, 23);
			frame.getContentPane().add(btnS);
			btnS.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int NewCounter = 0; 
					int NewWordlength = wordlength;
					int loseCount = 0;
					while(NewCounter != NewWordlength){
						if(wordF[NewCounter].equals("s")){
							button[NewCounter].setForeground(new Color(165, 42, 42));
							WinCount++;
						}
						if(!wordF[NewCounter].equals("s")){
							loseCount++;
						}
						NewCounter++;
						if (WinCount == NewWordlength){
							loseCount = 0;
							Correct++;
							if (GameMode == 1){
							try {
								JOptionPane.showMessageDialog(null, "Correct!", "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
								Game();
							} catch (InterruptedException e1) {
							
								}
							}
							if (GameMode == 2){
								WinAdd();

								
							}
							if (GameMode == 3){
								 wordlength = 1;Multi();	
							}
						}
						if(loseCount == NewWordlength){
							loseCount = 0;
							Health();	
						}
						}
					btnS.setEnabled(false);	
					}
				});	
			JButton btnT = new JButton("T");
			btnT.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btnT.setBounds(592, 312, 48, 23);
			frame.getContentPane().add(btnT);
			btnT.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int NewCounter = 0; 
					int NewWordlength = wordlength;
					int loseCount = 0;
					while(NewCounter != NewWordlength){
						if(wordF[NewCounter].equals("t")){
							button[NewCounter].setForeground(new Color(165, 42, 42));
							WinCount++;
						}
						if(!wordF[NewCounter].equals("t")){
							loseCount++;
						}
						NewCounter++;
						if (WinCount == NewWordlength){
							loseCount = 0;
							Correct++;
							if (GameMode == 1){
							try {
								JOptionPane.showMessageDialog(null, "Correct!", "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
								Game();
							} catch (InterruptedException e1) {
							
								}
							}
							if (GameMode == 2){
								WinAdd();

								
							}
							if (GameMode == 3){
								 wordlength = 1;Multi();	
							}
						}
						if(loseCount == NewWordlength){
							loseCount = 0;
							Health();	
						}
						}
					btnT.setEnabled(false);	
					}
				});	
			JButton btnU = new JButton("U");
			btnU.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btnU.setBounds(650, 311, 48, 23);
			frame.getContentPane().add(btnU);
			btnU.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int NewCounter = 0; 
					int NewWordlength = wordlength;
					int loseCount = 0;
					while(NewCounter != NewWordlength){
						if(wordF[NewCounter].equals("u")){
							button[NewCounter].setForeground(new Color(165, 42, 42));
							WinCount++;
						}
						if(!wordF[NewCounter].equals("u")){
							loseCount++;
						}
						NewCounter++;
						if (WinCount == NewWordlength){
							loseCount = 0;
							Correct++;
							if (GameMode == 1){
							try {
								JOptionPane.showMessageDialog(null, "Correct!", "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
								Game();
							} catch (InterruptedException e1) {
							
								}
							}
							if (GameMode == 2){
								WinAdd();

								
							}
							if (GameMode == 3){
								 wordlength = 1;Multi();	
							}
						}
						if(loseCount == NewWordlength){
							loseCount = 0;
							Health();	
						}
						}
					btnU.setEnabled(false);	
					}
				});	
			JButton btnV = new JButton("V");
			btnV.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btnV.setBounds(389, 345, 48, 23);
			frame.getContentPane().add(btnV);
			btnV.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int NewCounter = 0; 
					int NewWordlength = wordlength;
					int loseCount = 0;
					while(NewCounter != NewWordlength){
						if(wordF[NewCounter].equals("v")){
							button[NewCounter].setForeground(new Color(165, 42, 42));
							WinCount++;
						}
						if(!wordF[NewCounter].equals("v")){
							loseCount++;
						}
						NewCounter++;
						if (WinCount == NewWordlength){
							loseCount = 0;
							Correct++;
							if (GameMode == 1){
							try {
								JOptionPane.showMessageDialog(null, "Correct!", "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
								Game();
							} catch (InterruptedException e1) {
							
								}
							}
							if (GameMode == 2){
								WinAdd();

								
							}
							if (GameMode == 3){
								 wordlength = 1;Multi();	
							}
						}
						if(loseCount == NewWordlength){
							loseCount = 0;
							Health();
						}
						}
					btnV.setEnabled(false);	
					}
				});	
			JButton btnW = new JButton("W");
			btnW.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btnW.setBounds(447, 346, 48, 23);
			frame.getContentPane().add(btnW);
			btnW.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int NewCounter = 0; 
					int NewWordlength = wordlength;
					int loseCount = 0;
					while(NewCounter != NewWordlength){
						if(wordF[NewCounter].equals("w")){
							button[NewCounter].setForeground(new Color(165, 42, 42));
							WinCount++;
						}
						if(!wordF[NewCounter].equals("w")){
							loseCount++;
						}
						NewCounter++;
						if (WinCount == NewWordlength){
							loseCount = 0;
							Correct++;
							if (GameMode == 1){
							try {
								JOptionPane.showMessageDialog(null, "Correct!", "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
								Game();
							} catch (InterruptedException e1) {
							
								}
							}
							if (GameMode == 2){
								WinAdd();

								
							}
							if (GameMode == 3){
								 wordlength = 1;Multi();	
							}
						}
						if(loseCount == NewWordlength){
							loseCount = 0;
							Health();	
						}
						}
					btnW.setEnabled(false);	
					}
				});	
			JButton btnX = new JButton("X");
			btnX.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btnX.setBounds(505, 346, 48, 23);
			frame.getContentPane().add(btnX);
			btnX.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int NewCounter = 0; 
					int NewWordlength = wordlength;
					int loseCount = 0;
					while(NewCounter != NewWordlength){
						if(wordF[NewCounter].equals("x")){
							button[NewCounter].setForeground(new Color(165, 42, 42));
							WinCount++;
						}
						if(!wordF[NewCounter].equals("x")){
							loseCount++;
						}
						NewCounter++;
						if (WinCount == NewWordlength){
							loseCount = 0;
							Correct++;
							if (GameMode == 1){
							try {
								JOptionPane.showMessageDialog(null, "Correct!", "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
								Game();
							} catch (InterruptedException e1) {
							
								}
							}
							if (GameMode == 2){
								WinAdd();

								
							}
							if (GameMode == 3){
								 wordlength = 1;Multi();	
							}
						}
						if(loseCount == NewWordlength){
							loseCount = 0;
							Health();
						}
						}
					btnX.setEnabled(false);	
					}
				});	
			JButton btnY = new JButton("Y");
			btnY.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btnY.setBounds(563, 345, 48, 23);
			frame.getContentPane().add(btnY);
			btnY.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int NewCounter = 0; 
					int NewWordlength = wordlength;
					int loseCount = 0;
					while(NewCounter != NewWordlength){
						if(wordF[NewCounter].equals("y")){
							button[NewCounter].setForeground(new Color(165, 42, 42));
							WinCount++;
						}
						if(!wordF[NewCounter].equals("y")){
							loseCount++;
						}
						NewCounter++;
						if (WinCount == NewWordlength){
							loseCount = 0;
							Correct++;
							if (GameMode == 1){
							try {
								JOptionPane.showMessageDialog(null, "Correct!", "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
								Game();
							} catch (InterruptedException e1) {
							
								}
							}
							if (GameMode == 2){
								WinAdd();

								
							}
							if (GameMode == 3){
								 wordlength = 1;Multi();	
							}
						}
						if(loseCount == NewWordlength){
							loseCount = 0;
							Health();	
						}				
						}
					btnY.setEnabled(false);	
					}
				});	
			JButton btnZ = new JButton("Z");
			btnZ.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btnZ.setBounds(621, 346, 48, 23);
			frame.getContentPane().add(btnZ);	
			btnZ.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int NewCounter = 0; 
					int NewWordlength = wordlength;
					int loseCount = 0;
					while(NewCounter != NewWordlength){
						if(wordF[NewCounter].equals("z")){
							button[NewCounter].setForeground(new Color(165, 42, 42));
							WinCount++;
						}
						if(!wordF[NewCounter].equals("z")){
							loseCount++;
						}
						NewCounter++;
						if (WinCount == NewWordlength){
							loseCount = 0;
							Correct++;
							if (GameMode == 1){
							try {
								JOptionPane.showMessageDialog(null, "Correct!", "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
								Game();
							} catch (InterruptedException e1) {
							
								}
							}
							if (GameMode == 2){
								WinAdd();

								
							}
							if (GameMode == 3){
								 wordlength = 1;Multi();	
							}
						}
						if(loseCount == NewWordlength){
							loseCount = 0;
							Health();		
						}
						
			
					btnZ.setEnabled(false);	
						}
					}
				});	
			JButton btnCheat = new JButton("Cheat");
			btnCheat.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btnCheat.setBounds(650, 387, 77, 23);
			frame.getContentPane().add(btnCheat);
			btnCheat.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					 Correct++;
							if (GameMode == 1){
							try {
								JOptionPane.showMessageDialog(null, "Correct!", "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
								Game();
							} catch (InterruptedException e1) {
							
								}
							}
							if (GameMode == 2){
								WinAdd();

								
							}
							if (GameMode == 3){
								Multi();	
							}
						}
				});
			
		}
		public static void Ask(){
			word = JOptionPane.showInputDialog(frame, "Select a word");
		}
		public static void Win(){
			try {
				Thread.sleep(500); 
			} catch (InterruptedException e) {
			}
			try{
			    PrintWriter writer = new PrintWriter("stats.txt");
			    writer.println("1");
			    writer.println("0");
			    writer.println("0");
			    writer.close(); 
			} catch (IOException e) {
			   // do something
			}
			JOptionPane.showMessageDialog(null, "CONGRATULATIONS YOU WON! OPEN THE GAME AGAIN!", "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
			System.exit(0);
		}
	}

