package game;

import java.awt.*;
import java.util.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.Timer;

public abstract class Game 
implements KeyListener {
	

	public String name = "name";
	public static int racelevel;
	public static int money;
	public static int enginelevel;
	public static int tuninglevel;
	public static int turbolevel;
	public static int check;
	public static Random rn = new Random();
	public static Timer race1 = null, race2 = null, race3 = null;;
	public static int playerdistance = 0;
	public static int[] stats = new int[6];
	public static PrintWriter writer;
	static JFrame frame = new JFrame("Agile and Aggravated");
	private static JLabel label;
	
	private static JPanel panel = new JPanel();
	
	public static void main(String args[]) throws Exception {
		menu();
	}
	public static void menu() throws Exception{
		Sound Obj1; 
		Obj1 = new Sound();
		
		//load in graphics
		
		frame.getContentPane().setBackground(Color.BLACK);
		frame.setBounds(100, 100, 1200, 720);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel label = new JLabel();
		label.setIcon(new ImageIcon("D:\\workspace\\Agile\\menupic.gif"));
		label.setBounds(0, 0, 1250, 600);
		frame.getContentPane().add(label);
		int Counter = 0;
		FileReader filereader = null;
		try {
			filereader = new FileReader("stats.txt");
			BufferedReader reader = new BufferedReader(filereader);
			String str;
			while((str = reader.readLine())!= null){
				stats[Counter] = Integer.parseInt(str);
				Counter++;
			}
			
		} catch (FileNotFoundException e1) {
			
		} catch (IOException e1) {
		}
		
		JButton Start = new JButton("Start");
		Start.setBounds(257, 611, 89, 23);
		frame.getContentPane().add(Start);
		Start.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					writer = new PrintWriter("stats.txt");
				} catch (FileNotFoundException e1){
				}
				writer.println("1");
			    writer.println("0");
			    writer.println("0");
			    writer.println("0");
			    writer.println("250");
			    writer.println("1");
			    writer.close();
				
				careermode(); 
			}
		});
		JButton Quit = new JButton("Quit");
		Quit.setBounds(520, 611, 89, 23);
		frame.getContentPane().add(Quit);
		Quit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exit();
			}
		});
		System.out.print(stats[5]);
		if (stats[5] == 1){
		JButton Continue = new JButton("Continue");
		Continue.setBounds(804, 611, 89, 23);
		frame.getContentPane().add(Continue);
		Continue.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int Counter = 0;
				FileReader filereader = null;
				try {
					filereader = new FileReader("stats.txt");
					BufferedReader reader = new BufferedReader(filereader);
					String str;
					while((str = reader.readLine())!= null){
						stats[Counter] = Integer.parseInt(str);
						Counter++;
						racelevel = stats[0];
						enginelevel = stats[1];
						tuninglevel = stats[2];
						turbolevel = stats[3];
						money = stats[4];
						check = stats[5];
					}
					  try {
							writer = new PrintWriter("stats.txt");
						} catch (FileNotFoundException e1){
						}
					  	
					    writer.println(racelevel);
					    writer.println(enginelevel);
					    writer.println(tuninglevel);
					    writer.println(turbolevel);
					    writer.println(money);
					    writer.println(check);
					    writer.close();
					
				} catch (FileNotFoundException e1) {
					
				} catch (IOException e1) {
				}
				careermode();
			}
		});
		}
		frame.setVisible(true);
		//load in music
	   // Obj1.play();
	    		
	}
	
	 
		  

	  
	
	public static void careermode(){
		 try {
				writer = new PrintWriter("stats.txt");
			} catch (FileNotFoundException e1){
			}
		writer.println(racelevel);
	    writer.println(enginelevel);
	    writer.println(tuninglevel);
	    writer.println(turbolevel);
	    writer.println(money);
	    writer.println(check);
	    writer.close();
		int Counter = 0;
		FileReader filereader = null;
		try {
			filereader = new FileReader("stats.txt");
			BufferedReader reader = new BufferedReader(filereader);
			String str;
			while((str = reader.readLine())!= null){
				stats[Counter] = Integer.parseInt(str);
				Counter++;
				racelevel = stats[0];
				enginelevel = stats[1];
				tuninglevel = stats[2];
				turbolevel = stats[3];
				money = stats[4];
				check = stats[5];
			}
			
		} catch (FileNotFoundException e1) {
			
		} catch (IOException e1) {
		}
		//display career menu containing options :continue, shop, exit, options
		frame.getContentPane().removeAll();
		frame.getContentPane().repaint();
		frame.setResizable(false);
		frame.getContentPane().setBackground(Color.BLACK);
		frame.setBounds(100, 100, 1200, 720);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel label = new JLabel();
		label.setIcon(new ImageIcon("D:\\workspace\\Agile\\menupic.gif"));
		label.setBounds(0, 0, 1250, 600);
		frame.getContentPane().add(label);
		
		JButton Start = new JButton("Career");
		Start.setBounds(257, 611, 89, 23);
		frame.getContentPane().add(Start);
		Start.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//
				racinggamemain(); 
			}
		});
		JButton Shop = new JButton("Shop");
		Shop.setBounds(520, 611, 89, 23);
		frame.getContentPane().add(Shop);
		Shop.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				shop();
			}
		});
		
		
		JButton Quit = new JButton("Quit");
		Quit.setBounds(804, 611, 89, 23);
		frame.getContentPane().add(Quit);
		Quit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				System.exit(0);
			}
		});
		frame.setVisible(true);
		
	
		
		
		
	}
	
	
	
	
	public static int Carx1 = 10;
	public static int Carx2 = 10;
	public static int Carx3 = 10;
	public static int Carx4 = 10;
	public static void racinggamemain(){
		frame.getContentPane().removeAll();
		frame.getContentPane().repaint();
		frame.getContentPane().setBackground(Color.BLACK);
		frame.getContentPane().setBackground(Color.BLACK);
		frame.setBounds(100, 100, 1200, 720);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		//
		
	
		//Game Engine
		if (racelevel == 1){
			JLabel Car1 = new JLabel();
			Car1.setIcon(new ImageIcon("Car1.jpg"));
			Car1.setForeground(new Color(255, 255, 240));
			Car1.setBounds(Carx1, 50, 175, 94);
			frame.getContentPane().add(Car1);
			//
			JLabel Car2 = new JLabel();
			Car2.setIcon(new ImageIcon("Car2.jpg"));
			Car2.setForeground(new Color(255, 255, 240));
			Car2.setBounds(Carx2, 200, 175, 94);
			frame.getContentPane().add(Car2);
			
			//
			JLabel Car3 = new JLabel();
			Car3.setIcon(new ImageIcon("Car3.jpg"));
			Car3.setForeground(new Color(255, 255, 240));
			Car3.setBounds(Carx3, 370, 175, 94);
			frame.getContentPane().add(Car3);
			//
			JLabel Car4 = new JLabel();
			Car4.setIcon(new ImageIcon("Car4.jpg"));
			Car4.setForeground(new Color(255, 255, 240));
			Car4.setBounds(Carx4, 520, 175, 94);
			frame.getContentPane().add(Car4);
			Carx1 =10;
			Carx2 = 10;
			Carx3 = 10;
			Carx4 = 10;
			//
			race1 = new Timer(1000, new ActionListener(){ // Timer 4 seconds
	            public void actionPerformed(ActionEvent e) {
	            	
	            	int Car1Plus = rn.nextInt(50+(enginelevel*2))+1+(enginelevel*2)+(tuninglevel*4);
	            	Carx1 = Carx1+ Car1Plus;
	            	int Turbo = rn.nextInt(100)+1;
	            	if(Turbo <= turbolevel*2){
	            		Carx1=Carx1+150;
	            	}
	            	Car1.setBounds(Carx1, 50, 175, 94);
	            	//Car 2
	            	int Car2Plus = rn.nextInt(50+(6*2))+1+(6*2)+(0*4);
	            	Carx2 = Carx2+ Car2Plus;
	            	Turbo = rn.nextInt(100)+1;
	            	if(Turbo <= 2*2){
	            		Carx2=Carx2+150;
	            	}
	            	Car2.setBounds(Carx2, 200, 175, 94);
	            	//
	            	int Car3Plus = rn.nextInt(50+(5*2))+1+(5*2)+(8*4);
	            	Carx3 = Carx3+ Car3Plus;
	            	Turbo = rn.nextInt(100)+1;
	            	if(Turbo <= 4*2){
	            		Carx3=Carx3+150;
	            	}
	            	Car3.setBounds(Carx3, 370, 175, 94);
	            	//
	            	int Car4Plus = rn.nextInt(50+(5*2))+1+(5*2)+(10*4);
	            	Carx4 = Carx4+ Car4Plus;
	            	Turbo = rn.nextInt(100)+1;
	            	if(Turbo <= 8*2){
	            		Carx4=Carx4+150;
	            	}
	            	Car4.setBounds(Carx4, 520, 175, 94);
	            	
	            	if(Carx4 >= 1000 || Carx2 >= 1000 || Carx3 >= 1000 ){
	            		
	            		race1.stop();
	            		if(Carx1 > Carx2){
	            			money= money + 250;
	            		}
	            		if(Carx1 > Carx3){
	            			money= money + 250;

	            		}
	            		if(Carx1 > Carx4){
	            			money= money + 250;
	    				}
	            		money= money + 250;
	        		
	        				
	        				
						JOptionPane.showMessageDialog(null, "You Lose! " + money, "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
						
	            		careermode();
	            	}
	            	if(Carx1 >= 1000 && Carx1 > Carx2 && Carx1 >= Carx3 && Carx1 >= Carx4){
	            		race1.stop();
	            		if(Carx1 > Carx2){
	            			money= money + 250;
	            			
	        				
	        			
	            		}
	            		if(Carx1 > Carx3){
	            			money= money + 250;
	            	
	            		}
	            		if(Carx1 > Carx4){
	            			money= money + 250;
	            			
	    				}
	            		money= money + 250;
	            		
						JOptionPane.showMessageDialog(null, "You Win!", "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
						racelevel++;
					
	            		careermode();
	            		
	        			
	        				
	            	}
	            	
	            }
	        }); 
			
			race1.start();
			
			}
		if (racelevel == 2){
			 Carx1 = 10;
			Carx2 = 10;
			JLabel Car1 = new JLabel();
			Car1.setIcon(new ImageIcon("Car1.jpg"));
			Car1.setForeground(new Color(255, 255, 240));
			Car1.setBounds(Carx1, 50, 175, 94);
			frame.getContentPane().add(Car1);
			//
			JLabel Car2 = new JLabel();
			Car2.setIcon(new ImageIcon("Car5.jpg"));
			Car2.setForeground(new Color(255, 255, 240));
			Car2.setBounds(Carx2, 520, 175, 94);
			frame.getContentPane().add(Car2);
			//
			race2 = new Timer(1000, new ActionListener(){ // Timer 4 seconds
	            public void actionPerformed(ActionEvent e) {
	            	int Car1Plus = rn.nextInt(50+(enginelevel*2))+1+(enginelevel*2)+(tuninglevel*4);
	            	Carx1 = Carx1+ Car1Plus;
	            	int Turbo = rn.nextInt(100)+1;
	            	if(Turbo <= turbolevel*2){
	            		Carx1=Carx1+150;
	            	}
	            	Car1.setBounds(Carx1, 50, 175, 94);
	            	//Car 2
	            	int Car2Plus = rn.nextInt(50+(10*2))+1+(10*2)+(15*4);
	            	Carx2 = Carx2+ Car2Plus;
	            	Turbo = rn.nextInt(100)+1;
	            	if(Turbo <= 10*2){
	            		Carx2=Carx2+150;
	            	}
	            	Car2.setBounds(Carx2, 520, 175, 94);
	            	if(Carx2>= 1000){
	            		race2.stop();
	            		money= money + 500;
						JOptionPane.showMessageDialog(null, "You Lose! " + money, "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
						
	            		careermode();
	            	}
	            	if(Carx1 >= 1000 && Carx1 > Carx2){
	            		race2.stop();
	            		money= money + 2500;
						JOptionPane.showMessageDialog(null, "You Win!", "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
						racelevel++;
	            		careermode();
	            	}
	            	
	            	
	            }
	        }); 
			race2.start();
		}
		if (racelevel == 3){
			Carx1 = 10;
			Carx2 = 10;
			JLabel Car1 = new JLabel();
			Car1.setIcon(new ImageIcon("Car1.jpg"));
			Car1.setForeground(new Color(255, 255, 240));
			Car1.setBounds(Carx1, 50, 175, 94);
			frame.getContentPane().add(Car1);
			//
			JLabel Car2 = new JLabel();
			Car2.setIcon(new ImageIcon("finalcar.jpg"));
			Car2.setForeground(new Color(255, 255, 240));
			Car2.setBounds(Carx2, 520, 175, 94);
			frame.getContentPane().add(Car2);
			//
			race3= new Timer(1000, new ActionListener(){ // Timer 4 seconds
	            public void actionPerformed(ActionEvent e) {
	            	int Car1Plus = rn.nextInt(50+(enginelevel*2))+1+(enginelevel*2)+(tuninglevel*4);
	            	Carx1 = Carx1+ Car1Plus;
	            	int Turbo = rn.nextInt(100)+1;
	            	if(Turbo <= turbolevel*2){
	            		Carx1=Carx1+150;
	            	}
	            	Car1.setBounds(Carx1, 50, 175, 94);
	            	//Car 2
	            	int Car2Plus = rn.nextInt(50+(18*2))+1+(18*2)+(10*4);
	            	Carx2 = Carx2+ Car2Plus;
	            	Turbo = rn.nextInt(100)+1;
	            	if(Turbo <= 0*2){
	            		Carx2=Carx2+150;
	            	}
	            	Car2.setBounds(Carx2, 520, 175, 94);
	            	if(Carx2>= 1000){
	            		
	            		race3.stop();
	            		money= money + 500;
						JOptionPane.showMessageDialog(null, "You Lose! " + money, "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
						PrintWriter writer6;
						writer.println(racelevel);
					    writer.println(enginelevel);
					    writer.println(tuninglevel);
					    writer.println(turbolevel);
					    writer.println(money);
					    writer.println(check);
					    writer.close();
	            		careermode();
	            	}
	            	if(Carx1 >= 1000 && Carx1 > Carx2){
	            		race3.stop();
	        
						JOptionPane.showMessageDialog(null, "You Win! The End!", "InfoBox: " + " ", JOptionPane.INFORMATION_MESSAGE);
						
	            		careermode();
	            	}
	            
	            }
	        }); 
			race3.start();
		}
		writer.println(racelevel);
	    writer.println(enginelevel);
	    writer.println(tuninglevel);
	    writer.println(turbolevel);
	    writer.println(money);
	    writer.println(check);
	    writer.close();
		JLabel background = new JLabel();
		background.setIcon(new ImageIcon("D:\\workspace\\Agile\\road.jpg"));
		background.setBounds(-15, 0, 1057, 681);
		frame.getContentPane().add(background);
		
		JLabel finishline = new JLabel();
		finishline.setIcon(new ImageIcon("D:\\workspace\\Agile\\finishline.png"));
		finishline.setBounds(1034, 0, 164, 681);
		frame.getContentPane().add(finishline);
		frame.revalidate();
		frame.setVisible(true);
		//

	
	
		}
	public static void shop() {
		writer.println(racelevel);
	    writer.println(enginelevel);
	    writer.println(tuninglevel);
	    writer.println(turbolevel);
	    writer.println(money);
	    writer.println(check);
	    writer.close();
	    
		frame.getContentPane().removeAll();
		frame.getContentPane().repaint();
		frame.getContentPane().setBackground(Color.BLACK);
		frame.setBounds(100, 100, 1200, 720);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton Back = new JButton("Back");
		Back.setBounds(75, 30, 89, 23);
		frame.getContentPane().add(Back);
		Back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//
				careermode(); 
			}
		});
		JButton Turbo = new JButton("250$ Turbo: " + turbolevel);
		Turbo.setBounds(174, 30, 143, 23);
		frame.getContentPane().add(Turbo);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("D:\\workspace\\Agile\\garage.jpg"));
		lblNewLabel.setBounds(0, 68, 1184, 613);
		frame.getContentPane().add(lblNewLabel);
		
		JButton Tuning = new JButton("250$ Tuning: " + tuninglevel);
		Tuning.setBounds(327, 30, 143, 23);
		frame.getContentPane().add(Tuning);
		
		JButton Engine = new JButton("250$ Engine: " + enginelevel);
		Engine.setBounds(480, 30, 143, 23);
		frame.getContentPane().add(Engine);
		
		JButton Money = new JButton(money+ "$");
		Money.setBounds(633, 30, 143, 23);
		frame.getContentPane().add(Money);
      	if (turbolevel == 15){
      		Turbo.setEnabled(false);
      	}
      	if (tuninglevel == 15){
      		Tuning.setEnabled(false);
      	}
      	if (enginelevel == 15){
      		Engine.setEnabled(false);
      	}
      	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    frame.pack();
	    frame.setSize(1250, 720);
	    frame.setVisible(true);
	    try {
			writer = new PrintWriter("stats.txt");
		} catch (FileNotFoundException e1){
		}
	    writer.println(racelevel);
	    writer.println(enginelevel);
	    writer.println(tuninglevel);
	    writer.println(turbolevel);
	    writer.println(money);
	    writer.println(check);
	    writer.close();
	   
	   if (money >= 250){
	    Turbo.addActionListener(new turboupgrade());
        Tuning.addActionListener(new tuningupgrade());
        Engine.addActionListener(new engineupgrade());        
	   }
	   Money.addActionListener(new moneycheat());
	   
		
	}
	
	static class turboupgrade implements ActionListener {		
		public void actionPerformed(ActionEvent e) {			
			
				try {
					money = money - 250;
					turbolevel++;
					shop();
				} catch (Exception e1) {
				}					
		}	  
	  }
	static class tuningupgrade implements ActionListener {		
		public void actionPerformed(ActionEvent e) {			
			
				try {
					money = money - 250;
					tuninglevel++;	
					shop();
				} catch (Exception e1) {
				}					
		}	  
	  }
	static class engineupgrade implements ActionListener {		
		public void actionPerformed(ActionEvent e) {			
			
				try {
					money = money- 250;
					enginelevel++;		
					shop();
				} catch (Exception e1) {
				}					
		}	  
	  } 
	static class moneycheat implements ActionListener {		
		public void actionPerformed(ActionEvent e) {			
			
				try {
					money = money + 99999999;	
					shop();
				} catch (Exception e1) {
				}					
		}	  
	  }
	public static void exit(){
		save();
		System.exit(0);
	}
	public static void save(){
		racelevel = stats[0];
		enginelevel = stats[1];
		tuninglevel = stats[2];
		turbolevel = stats[3];
		money = stats[4];
		check = stats[5];
		 PrintWriter writer2;
			try {
				
			writer2 = new PrintWriter("stats.txt");
		    writer2.println(racelevel);
		    writer2.println(enginelevel);
		    writer2.println(tuninglevel);
		    writer2.println(turbolevel);
		    writer2.println(money);
		    writer2.println(check);
		    writer2.close();
			} catch (FileNotFoundException e1) {
				
			}
	}
}

